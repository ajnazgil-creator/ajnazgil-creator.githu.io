document.addEventListener('DOMContentLoaded', () => {

    const loader = document.getElementById('pageLoader');
    if (loader) {
        setTimeout(() => loader.classList.add('hidden'), 800);
    }

    const navbar = document.getElementById('navbar');
    const scrollTop = document.getElementById('scrollTop');
    window.addEventListener('scroll', () => {
        const y = window.scrollY;
        navbar && (y > 50 ? navbar.classList.add('scrolled') : navbar.classList.remove('scrolled'));
        scrollTop && (y > 400 ? scrollTop.classList.add('visible') : scrollTop.classList.remove('visible'));
        checkReveal();
    });

    scrollTop && scrollTop.addEventListener('click', (e) => {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('open');
            const spans = navToggle.querySelectorAll('span');
            const open = navMenu.classList.contains('open');
            if (spans[0]) spans[0].style.transform = open ? 'rotate(45deg) translate(5px, 5px)' : '';
            if (spans[1]) spans[1].style.opacity = open ? '0' : '1';
            if (spans[2]) spans[2].style.transform = open ? 'rotate(-45deg) translate(5px, -5px)' : '';
        });
    }

    function checkReveal() {
        const reveals = document.querySelectorAll('.reveal:not(.visible), .reveal-card:not(.visible)');
        reveals.forEach(el => {
            const rect = el.getBoundingClientRect();
            if (rect.top < window.innerHeight - 80) {
                el.classList.add('visible');
            }
        });
    }
    checkReveal();

    const counters = document.querySelectorAll('.stat-number[data-target]');
    const countObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !entry.target.dataset.counted) {
                entry.target.dataset.counted = true;
                animateCounter(entry.target);
            }
        });
    }, { threshold: 0.5 });
    counters.forEach(c => countObserver.observe(c));

    function animateCounter(el) {
        const target = parseInt(el.dataset.target);
        const duration = 1800;
        const step = target / (duration / 16);
        let current = 0;
        const timer = setInterval(() => {
            current = Math.min(current + step, target);
            el.textContent = Math.floor(current).toLocaleString('ru');
            if (current >= target) {
                el.textContent = target.toLocaleString('ru');
                clearInterval(timer);
            }
        }, 16);
    }

    const flashes = document.querySelectorAll('.flash');
    flashes.forEach(f => {
        setTimeout(() => {
            f.style.opacity = '0';
            f.style.transform = 'translateX(120%)';
            setTimeout(() => f.remove(), 400);
        }, 5000);
    });

    document.querySelectorAll('a[href^="#"]').forEach(a => {
        a.addEventListener('click', (e) => {
            const target = document.querySelector(a.getAttribute('href'));
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                if (navMenu) navMenu.classList.remove('open');
            }
        });
    });

    const heroTruckIcon = document.querySelector('.hero-truck-card .truck-card-icon');
    if (heroTruckIcon) {
        setInterval(() => {
            heroTruckIcon.style.transform = 'scale(1.1) rotate(-5deg)';
            setTimeout(() => heroTruckIcon.style.transform = '', 300);
        }, 3000);
    }

    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', (e) => {
            const btn = document.getElementById('bookSubmit');
            if (btn && !btn.disabled) {
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Оформление...';
            }
        });
    }

    document.querySelectorAll('.service-option-card').forEach(card => {
        const input = card.querySelector('input[type="checkbox"]');
        const body = card.querySelector('.service-option-body');
        if (input && body) {
            input.addEventListener('change', () => {
                if (input.checked) {
                    body.style.transform = 'scale(1.02)';
                    setTimeout(() => body.style.transform = '', 200);
                }
            });
        }
    });

    const adminNav = document.querySelector('.admin-nav');
    if (adminNav && window.innerWidth <= 768) {
        const sidebar = document.querySelector('.admin-sidebar');
        if (sidebar) sidebar.style.display = 'none';
    }

    document.querySelectorAll('.filter-select').forEach(sel => {
        sel.addEventListener('change', () => {
            sel.style.borderColor = 'var(--primary)';
        });
    });

    document.querySelectorAll('.truck-card-full').forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.querySelector('.truck-img-placeholder i') &&
            (card.querySelector('.truck-img-placeholder i').style.transform = 'scale(1.1) translateY(-4px)');
        });
        card.addEventListener('mouseleave', () => {
            card.querySelector('.truck-img-placeholder i') &&
            (card.querySelector('.truck-img-placeholder i').style.transform = '');
        });
    });

});
